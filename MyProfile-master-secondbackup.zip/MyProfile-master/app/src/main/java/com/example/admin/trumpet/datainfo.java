package com.example.admin.trumpet;




public class datainfo {
    private String coin, email, name, points;

    public datainfo() {
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email){this.email = email;}

    public String getname(){ return name; }
    public void setname(String name){this.name = name;}

    public String getcoin(){ return coin; }
    public void setcoin(String name){this.coin = coin;}

    public String getpoints(){ return points; }
    public void setpoints(String name){this.name = points;}
}
